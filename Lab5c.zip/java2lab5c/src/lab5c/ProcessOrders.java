package lab5c;

import java.security.SecureRandom;

public class ProcessOrders implements Runnable {

//random sleep time for thread
	private static final SecureRandom generator = new SecureRandom();
	
	//create local order object
	private Order order;
	
	//create accumulator for total cost
	private static double totalCost = 0;    
	
	//create sleep time variable
	private final int sleepTime;
	
	// constructor
	public ProcessOrders(Order order) {
		this.order = order;
		
	      // pick random sleep time between 0 and 5 seconds
	      sleepTime = generator.nextInt(5000); // milliseconds

	}
		
      @Override
      public void run() {
    	  
         try {
        	// put thread to sleep to avoid concurrency problems
            Thread.sleep(sleepTime); // put thread to sleep
            
            // create new ShippingService object
            ShippingService shipService = new ShippingService();
             
            // create new ShippingLabel object
         	ShippingLabel shipLabel1 =
                     shipService.getShippingLabel(order.getCustomerName(),
                             order.getCustomerAddress(),
                             order.getWeightInPounds());

         	//print to string for ShippingLabel objects
         	System.out.printf("%s%n", shipLabel1);
         	
         	//accumulate total cost into static variable totalCost
         	totalCost += shipLabel1.getCostInCents();


         }       
         catch (InterruptedException exception) {
            exception.printStackTrace();
            Thread.currentThread().interrupt(); // re-interrupt the thread
         } 

      } 
      
      //create method to return totalCost 
      public static double getTotalCost() {
    	  return totalCost;
      }
}
