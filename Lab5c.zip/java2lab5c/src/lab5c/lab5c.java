/**
Luke McClure
CMSY-167-002
This program: Prints shipping labels for customer orders using executorservice to manage threads  
*/
package lab5c;

// imports
import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class lab5c {
    
    

	@SuppressWarnings("unused")
	public static void main(String[] args) {
     
		//creating orders
    	Order order1 = new Order("John Terrance", "2549 Willow Bend", 50.5);
        Order order2 = new Order("Phillip Skyler","9283 Glendower Lane", 40); 
        Order order3 = new Order("Jordan Reynolds","3923 Flowers Road", 2); 
        Order order4 = new Order("Will Smith","615 Red Road", 30); 
        Order order5 = new Order("Susan Ronalds","6135 Orange Court", 22.6); 
        Order order6 = new Order("Sally McDonald","1623 Black Blvd", 15);
        
        //create list and fill with orders
        List<Order> orders = new ArrayList<Order>();
        orders.add(order1);
        orders.add(order2);
        orders.add(order3);
        orders.add(order4);
        orders.add(order5);
        orders.add(order6);
                
        // create executor service to manage the thread pool using cached thread pool
        ExecutorService executorService = Executors.newCachedThreadPool();
        
        // loop through the orders list to process each order
        for (int i = 0; i < 6; i++) {    
            ProcessOrders orderRun = new ProcessOrders(orders.get(i));
        	executorService.execute(orderRun);

        }

        // putting main thread to sleep in order to allow time for labels to print and total cost to accumulate
        try {
        	Thread.currentThread().sleep(10000);
        } 
        catch (InterruptedException exception) {
            exception.printStackTrace();
            Thread.currentThread().interrupt(); // re-interrupt the thread
        } 

        // shut down ExecutorService--it decides when to shut down threads
        executorService.shutdown();

        // print out total cost
        System.out.println("Total Cost for all orders = " + ProcessOrders.getTotalCost());
        

    }



}