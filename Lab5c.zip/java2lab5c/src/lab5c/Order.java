
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5c;

// create order class and set variables
public class Order {
    String customerName;
    String customerAddress;
    double weightInPounds;
    
    public Order(String customerName, String customerAddress, double weightInPounds)
    {
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.weightInPounds = weightInPounds;
    }
    
    //getters and setters
	public void setCustomerName(String customerName) {
	    this.customerName = customerName;
	}
	
	public String getCustomerName() {
	    return customerName;
	}
	
	public void setCustomerAddress(String customerAddress) {
	    this.customerAddress = customerAddress;
	}
	
	public String getCustomerAddress() {
	    return customerAddress;
	}
	
	public void setWeightInPounds(double weightInPounds){
	    this.weightInPounds = weightInPounds;
	}
	
	public double getWeightInPounds() {
	    return weightInPounds;
	}

}